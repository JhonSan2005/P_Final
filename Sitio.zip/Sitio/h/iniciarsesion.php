<?php
include("funciones.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    // Llamar a la función de inicio de sesión
    iniciarSesion($correo, $password);
}
?>