<!-- <?php
include("funciones.php");
$correo = $_POST['correo'];
$password = $_POST['password'];

// Llamar a la función de registro
$resultado = iniciarSesion($correo, $password);

?>
