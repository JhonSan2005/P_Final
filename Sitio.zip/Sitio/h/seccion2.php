<body>
    <audio autoplay>

       <source src="mp3/misc308.mp3">


    </audio>

    <!----------------------- Contenedor principal -------------------------->

     <div class="container d-flex justify-content-center align-items-center min-vh-100">

    <!----------------------- Contenedor de registrarse -------------------------->

       <div class="row border rounded-5 p-3 bg-white shadow box-area">

    <!--------------------------- Cuadro izquierdo ----------------------------->

       <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box" style="background: #FF0000;">
           <div class="featured-image mb-3">
            <video controls autoplay class="img-fluid" style="width: auto;">
  <source src="mp3/trailer.mp4" type="video/mp4">
  Tu navegador no admite el elemento de video.
</video>
           </div>
           <p class="text-white fs-2" style="font-family: 'Courier New', Courier, monospace; font-weight: 600;"></p>
           <small class="text-white text-wrap text-center" style="width: 17rem;font-family: 'Courier New', Courier, monospace;"></small>
       </div> 

    <!-------------------- ------ Caja derecha ---------------------------->
    
       <div class="col-md-6 right-box">
          <div class="row align-items-center">
                <div class="header-text mb-2">
                     <h2>Hola, Bienvenidos a Repueestos JJJ</h2>
                     <p>Estamos felices de tenerte de vuelta.</p>
                </div>
    <form action="iniciarsesion.php" method="post">
    <div class="input-group mb-3">
        <input type="email" class="form-control form-control-lg bg-light fs-6" name="correo" placeholder="correo">
    </div>
    <div class="input-group mb-1">
        <input type="password" class="form-control form-control-lg bg-light fs-6" name="password" placeholder="Password">
    </div>
    <button type="submit" class="btn btn-lg btn-danger w-100 fs-6" style="background-color: #FF0000;">Iniciar Sesión</button>
</form>


<div class="row">
<div class="row">
    <small> ¿No tienes cuenta? <a href="controlador.php?seccion=seccion3" style="color: #FF0000;">Registrarse</a></small>
       <small> ¿No tienes cuenta? <a href="recuperar.html" style="color: #FF0000;">¿Olvido su contraseña?</a></small>
</div>

                </div>
          </div>
       </div> 

      </div>
    </div>
    
</body>
</html>