
<?php
include("funciones.php");

// <!-- Funcion de la seccion de registrase -->
$documento = $_POST['documento'];
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$password = $_POST['password'];

// Llamar a la función de registro
$resultado = registro_usuario::registro($documento, $nombre, $correo, $password);

 ?>
