<!DOCTYPE html>
<html lang="en">
<head>
    <style>
body {
    background-image: url('imganes/klole.png');
    background-size: cover;
    background-repeat: no-repeat;
    width: auto;
}
/* Estilos generales */
body {
    font-family: 'Courier New', Courier, monospace;
    background-color: #f5f5f5;
}

.container {
    max-width: 600px; /* Reducimos el ancho máximo del contenedor */
    margin: 0 auto;
}

.box-area {
    background-color: #fff;
    border-radius: 20px;
    box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
    overflow: hidden;
    width: 80%; /* Reducimos el ancho del cuadro */
    margin: 0 auto; /* Centramos el cuadro horizontalmente */
}

/* Estilos para el cuadro izquierdo */
.left-box {
    background-color: #FF0000;
    color: #fff;
    padding: 30px; /* Reducimos el padding */
    text-align: center;
}

.left-box .featured-image {
    width: 200px; /* Reducimos el tamaño de la imagen */
    height: 200px;
    border-radius: 50%;
    overflow: hidden;
}

.left-box .featured-image video {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

/* Estilos para el cuadro derecho */
.right-box {
    padding: 30px; /* Reducimos el padding */
}

.right-box .header-text h2 {
    font-size: 28px; /* Reducimos el tamaño de la fuente */
    font-weight: 700;
    margin-bottom: 10px;
}

.right-box .header-text p {
    font-size: 16px; /* Reducimos el tamaño de la fuente */
    color: #777;
    margin-bottom: 20px; /* Reducimos el margen inferior */
}

.right-box .input-group {
    margin-bottom: 15px; /* Reducimos el margen inferior */
}

.right-box .input-group .form-control {
    border: none;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 12px 16px; /* Reducimos el padding */
    font-size: 14px; /* Reducimos el tamaño de la fuente */
}

.right-box .btn {
    border-radius: 10px;
    font-size: 14px; /* Reducimos el tamaño de la fuente */
    padding: 12px 24px; /* Reducimos el padding */
}


        
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="style.css">
    <title>Repuestos JJJ</title>
    
</head>
<body>
     <audio autoplay>

        <source src="mp3/1-formula-motor.mp3">


    </audio>
    

    <!----------------------- Contenedor principal -------------------------->

     <div class="container d-flex justify-content-center align-items-center min-vh-100">

    <!----------------------- Contenedor de registrarse -------------------------->

       <div class="row border rounded-5 p-3 bg-white shadow box-area">

    <!--------------------------- Cuadro izquierdo ----------------------------->

       <div class="col-md-6 rounded-4 d-flex justify-content-center align-items-center flex-column left-box" style="background: #FF0000;">
           <div class="featured-image mb-3">
            <video controls autoplay class="img-fluid" style="width: auto;">
  <source src="mp3/trailer.mp4" type="video/mp4">
  Tu navegador no admite el elemento de video.
</video>
           </div>
           <p class="text-white fs-2" style="font-family: 'Courier New', Courier, monospace; font-weight: 600;"></p>
           <small class="text-white text-wrap text-center" style="width: 17rem;font-family: 'Courier New', Courier, monospace;"></small>
       </div> 

    <!-------------------- ------ Caja derecha ---------------------------->
    
       <div class="col-md-6 right-box">
          <div class="row align-items-center">
                <div class="header-text mb-4">
                     <h2>Hola</h2>
                     <p>Admistrador</p>
                </div>
                
                <div class="input-group mb-3">
                    <input type="text" class="form-control form-control-lg bg-light fs-6" placeholder="Usuario">
                </div>
                <div class="input-group mb-1">
                    <input type="password" class="form-control form-control-lg bg-light fs-6" placeholder="Contraseña">
                </div>
                <div class="input-group mb-5 d-flex justify-content-between">
                </div>
                <div class="input-group mb-3">
                   <div class="input-group mb-3">
    <a href="admistrador2.html" class="btn btn-lg btn-danger w-100 fs-6" style="background-color: #FF0000;">Inicia Sesión</a>
</div>


                <div class="row">
                   <div class="row">
                    

      
</div>

                </div>
          </div>
       </div> 

      </div>
    </div>

</body>
</html>