# Sitio-base-bootstrap-v1-2024
Sitio base en php con responsividad Bootstrap
