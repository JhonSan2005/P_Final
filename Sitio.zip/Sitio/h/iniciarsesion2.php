<?php
include("funciones.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $correo = $_POST['correo'];
    $password = $_POST['password'];

    // Llamar a la función de iniciar sesión
    $resultado = inicio_sesion_usuario::iniciar_sesion($correo, $password);

    // Mostrar el resultado en caso de error
    if ($resultado) {
        echo $resultado;
    }
}
?>