<?php
/**
 * Autor: Camilo Figueroa (Crivera)
 * Redirecciona a la sección de inicio del sitio.
 */

header("location:controlador.php");

?>
