<?php
//********************************Inisiar sesion************************************* */
function iniciarSesion($correo, $password)
{
    // Paso 1: Conexión a la base de datos
    $conexion = mysqli_connect('localhost', 'root', '', 'jj_bd');

    // Verificar si la conexión es exitosa
    if ($conexion->connect_error) {
        die("Error de conexión: " . $conexion->connect_error);
    }

    // Paso 2: Consulta SQL preparada para verificar el correo y la contraseña
    $sql = $conexion->prepare("SELECT * FROM clientes WHERE correo = ? AND password = ?");
    $sql->bind_param("ss", $correo, $password);
    $sql->execute();
    $resultado = $sql->get_result();

    // Paso 3: Verificar el resultado de la consulta
    if ($resultado->num_rows > 0) {
        // Inicio de sesión exitoso
        session_start();  // Iniciar sesión
        $_SESSION['correo'] = $correo;
        header("Location: controlador.php?seccion=seccion");
        exit();  // Terminar el script después de redirigir
    } else {
        // Mostrar mensaje de error si la autenticación falla
        echo "Correo o contraseña incorrectos";
    }

    // Paso 4: Cerrar la conexión a la base de datos
    $sql->close();
    $conexion->close();
}

   //******************************OBTEENCION DE DATOS DEL USUSARIO****************************//


   //Creacion De una Función
   function registro($documento, $nombre,$correo,$password)
{
    //Paso 1: Conexión a la base de datos
    $conexion = mysqli_connect('localhost', 'root', '', 'jj_bd');
    // Paso 2: Consulta SQL para contar los registros en la tabla "Personas"
    $sql = "INSERT INTO clientes (documento, nombre , correo , password) VALUES ('$documento', '$nombre', '$correo', '$password')";
     // Ejecuta una consulta
    $resultado = $conexion->query($sql);
// Paso 3: Obtener el resultado de la consulta
    if ($resultado) {
        header("location:controlador.php?seccion=seccion4");
        return "Inisio de Sesion exitoso";
    } else {
        return "Error en el registro: " . $conexion->error;
    }
     // Paso 4: Cerrar la conexión a la base de datos
    $conexion->close();

   
}
 //******************************ELIMINACION DE DATOS DEL USUSARIO****************************//

//Creacion De una Función
function eliminar($Documento)
{
    //Paso 1: Conexión a la base de datos
    $conexion = mysqli_connect('localhost', 'root', 'root', '20231019a');
    // Paso 2: Consulta SQL para contar los registros en la tabla "Personas"
    $sql = "DELETE FROM Usuario Where Documento=$Documento";
    // Ejecuta una consulta
    $resultado = $conexion->query($sql);
    // Paso 3: Obtener el resultado de la consulta
    if ($resultado) {
        return "Elimiación  exitoso";
    } else {
        return "Error en al Eliminar: " . $conexion->error;
    }
    // Paso 4: Cerrar la conexión a la base de datos
    $conexion->close();
}


//******************************ACTUALIZAR DE DATOS DEL USUSARIO****************************//

// Creación de una función para actualizar datos
function actualizar($Documento, $Nombre, $Sitio)
{
    // Paso 1: Conexión a la base de datos
    $conexion = mysqli_connect('localhost', 'root', 'root', '20231019a');

    // Verificar si la conexión se realizó correctamente
    if (!$conexion) {
        return "Error en la conexión a la base de datos: " . mysqli_connect_error();
    }

    // Paso 2: Consulta SQL para actualizar los datos en la tabla "Usuario"
    $sql = "UPDATE Usuario SET Nombre = '$Nombre', Sitio = '$Sitio' WHERE Documento = $Documento";

    // Ejecutar la consulta
    $resultado = mysqli_query($conexion, $sql);

    // Paso 3: Verificar si la consulta se ejecutó con éxito
    if ($resultado) {
        // Paso 4: Cerrar la conexión a la base de datos
        mysqli_close($conexion);
        return "Actualización exitosa";
    } else {
        return "Error al actualizar: " . mysqli_error($conexion);
    }
}
 

