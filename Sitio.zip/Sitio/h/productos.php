
<?php
include("funciones.php");

// Llamar a la función para mostrar los productos
Productos::mostrarProductos();
?>