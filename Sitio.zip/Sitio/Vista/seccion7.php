<?php
$seccion7 = "Index_Admin";
?>

<head>
    <title> <?php echo "$seccion7"; ?></title>
</head>

<div class="container-fluid min-vh-100 d-flex flex-column">
        <div class="row justify-content-center">
            <div class="col-12 text-center my-3">
                <img src="../img/logol.png" alt="Logo" class="img-fluid" style="max-height: 180px; max-width: 300px;">
            </div>
</div>
