<?php
$seccion10 = "Carrito de Compra";
?>

<head>
    <title> <?php echo "$seccion10"; ?></title>
</head>