<?php
$seccion13 = "Confirmacion";
?>

<head>
    <title> <?php echo "$seccion13"; ?></title>
</head>
