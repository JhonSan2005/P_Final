<?php
$seccion3 = "Registro";
?>

<head>
    <title> <?php echo "$seccion3"; ?></title>
</head>
<div class="container-fluid min-vh-100 d-flex flex-column">
        <div class="row justify-content-center">
            <div class="col-12 text-center my-3">
                <img src="css/img/logol.png" alt="Logo" class="img-fluid" style="max-height: 180px; max-width: 300px;">
            </div>
        </div>

<div class="verifica">
    <h1 class="text-center">¡Gracias por tu compra!</h1>
    <div class="text-center">
      <img src="https://vitrimat.com/wp-content/uploads/2021/04/chulo-300x283.png" class="img-fluid">
    </div>
    <div class="text-center mt-4">
      <a href="index.html" class="btn btn-success">Regresar</a>
    </div>
  </div>

