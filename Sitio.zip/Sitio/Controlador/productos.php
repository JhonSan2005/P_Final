
<?php
include("../Modelo/funciones.php");

// Llamar a la función para mostrar los productos
Productos::mostrarProductos();
?>