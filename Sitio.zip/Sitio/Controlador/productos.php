<?php
include("../Modelo/funciones.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recuperar datos del POST
    $id_producto = $_POST['product_id'];
    $nombre_producto = $_POST['product_name'];
    $precio = $_POST['product_price'];
    $impuesto = $_POST['product_tax'];
    $stock = $_POST['product_stock'];
    $id_categoria = $_POST['product_category'];
    $descripcion = $_POST['product_description'];

    // Manejo del archivo
    $imagen = $_FILES['product_image'];
    $imagen_nombre = $imagen['name'];
    $imagen_tmp = $imagen['tmp_name'];
    $imagen_tamano = $imagen['size'];
    $imagen_error = $imagen['error'];

    // Verificar que no haya errores en la subida del archivo
    if ($imagen_error === 0) {
        // Obtener la extensión del archivo
        $imagen_ext = pathinfo($imagen_nombre, PATHINFO_EXTENSION);
        // Generar un nombre único para la imagen
        $imagen_nombre_nuevo = uniqid('producto_', true) . '.' . $imagen_ext;
        // Ruta de destino para guardar la imagen
        $imagen_destino = '../img/' . $imagen_nombre_nuevo;

        // Mover el archivo temporal a la ubicación deseada
        if (move_uploaded_file($imagen_tmp, $imagen_destino)) {
            // Llamar al método para agregar producto a la base de datos
            $resultado = Productos::mostrarProductos($id_producto, $nombre_producto, $precio, $impuesto, $stock, $id_categoria, $descripcion, $imagen_nombre_nuevo);

            // Mostrar el resultado o error
            if ($resultado) {
                echo $resultado;
            }
        } else {
            echo "Error al subir el archivo.";
        }
    } else {
        echo "Error: " . $imagen_error;
    }
}
?>
